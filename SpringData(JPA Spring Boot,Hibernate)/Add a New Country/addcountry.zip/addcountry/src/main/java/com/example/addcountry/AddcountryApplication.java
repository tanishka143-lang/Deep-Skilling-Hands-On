package com.example.addcountry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddcountryApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddcountryApplication.class, args);
	}

}
